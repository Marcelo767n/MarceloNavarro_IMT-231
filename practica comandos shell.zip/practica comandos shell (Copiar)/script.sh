#!/bin/bash
echo "Este es un script de prueba"
