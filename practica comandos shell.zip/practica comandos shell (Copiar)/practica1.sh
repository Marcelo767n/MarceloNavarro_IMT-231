#!/bin/bash
pwd
cd /tmp
ls
cd ~
mkdir -p practica_shell
cd practica_shell
pwd


