#!/bin/bash
echo "ingrese su nombre"
read nombre 
echo "hola, $nombre"


